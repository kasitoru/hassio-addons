#!/usr/bin/env bash

./Agent reset
