#!/usr/bin/env bash

./Agent register
