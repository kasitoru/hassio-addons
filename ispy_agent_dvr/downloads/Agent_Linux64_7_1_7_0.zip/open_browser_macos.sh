#!/bin/bash

# --- Default Configuration ---
DEFAULT_HOST="localhost"
DEFAULT_PORT=8090
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
PORT_FILE="$SCRIPT_DIR/Media/XML/port.txt"

# --- Argument Parsing ---
INPUT_URL="$1" # Use argument 1 as URL

# --- URL Logic ---
if [ -z "$INPUT_URL" ]; then
    # No URL provided, construct from port file or defaults
    HOST="$DEFAULT_HOST"
    
    if [ -f "$PORT_FILE" ]; then
        PORT=$(cat "$PORT_FILE" | tr -d '\r\n')
        echo "Using port from file: $PORT"
    else
        PORT=$DEFAULT_PORT
        echo "Port file not found, using default: $PORT"
    fi
    
    URL="http://$HOST:$PORT"
    echo "Using default configuration: $URL"
else
    # URL provided, use it directly
    URL="$INPUT_URL"
    
    # Add http:// if no protocol specified
    if [[ ! "$URL" =~ ^https?:// && ! "$URL" =~ ^ftp:// ]]; then
        URL="http://$URL"
        echo "Added http:// protocol to URL"
    fi
    
    echo "Using specified URL: $URL"
fi

echo "Opening: $URL"

# --- WebRTC Flags ---
FLAGS="--webrtc-ip-handling-policy=default --allow-insecure-localhost --allow-running-insecure-content --autoplay-policy=no-user-gesture-required --disable-infobars --disable-extensions"

# --- Browser Search ---
echo "Searching for a compatible browser..."

# Array of paths to browser executables on macOS
BROWSERS=(
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"
    "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"
    "/Applications/Vivaldi.app/Contents/MacOS/Vivaldi"
    "/Applications/Chromium.app/Contents/MacOS/Chromium"
    "/Applications/Arc.app/Contents/MacOS/Arc"
)

for browser_path in "${BROWSERS[@]}"; do
    if [ -f "$browser_path" ]; then
        echo "Found compatible browser: $(basename "$browser_path")"
        # Launch in the background
        nohup "$browser_path" $FLAGS --app="$URL" >/dev/null 2>&1 &
        echo "Browser launch initiated."
        
        # Display usage information
        echo
        echo "Usage: $0 [url]"
        echo "  url - Full URL to open (optional)"
        echo "        If not provided, uses localhost with port from port.txt (default: 8090)"
        echo "        Protocol (http://) will be added automatically if not specified"
        echo
        echo "Examples:"
        echo "  $0                              (uses localhost and port from file)"
        echo "  $0 localhost:3000               (opens http://localhost:3000)"
        echo "  $0 192.168.1.100:8080          (opens http://192.168.1.100:8080)"
        echo "  $0 https://example.com          (opens https://example.com)"
        echo "  $0 http://example.com:8080/app  (opens http://example.com:8080/app)"
        
        exit 0
    fi
done

# --- Fallback ---
echo "No compatible Chromium-based browser found, falling back to Safari."
echo "Warning: Required flags cannot be applied to Safari."

if open -a Safari "$URL"; then
    echo "Browser launched successfully."
    
    # Display usage information
    echo
    echo "Usage: $0 [url]"
    echo "  url - Full URL to open (optional)"
    echo "        If not provided, uses localhost with port from port.txt (default: 8090)"
    echo "        Protocol (http://) will be added automatically if not specified"
    echo
    echo "Examples:"
    echo "  $0                              (uses localhost and port from file)"
    echo "  $0 localhost:3000               (opens http://localhost:3000)"
    echo "  $0 192.168.1.100:8080          (opens http://192.168.1.100:8080)"
    echo "  $0 https://example.com          (opens https://example.com)"
    echo "  $0 http://example.com:8080/app  (opens http://example.com:8080/app)"
    
else
    echo "Failed to open Safari."
    echo "Please open this URL in your browser: $URL"
    echo
    echo "Usage: $0 [url]"
    echo "  url - Full URL to open (optional)"
    echo "        If not provided, uses localhost with port from port.txt (default: 8090)"
    echo "        Protocol (http://) will be added automatically if not specified"
    
    exit 1
fi