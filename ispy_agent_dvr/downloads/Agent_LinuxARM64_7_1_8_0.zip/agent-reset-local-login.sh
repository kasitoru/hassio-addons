#!/usr/bin/env bash

./Agent reset-local-login
