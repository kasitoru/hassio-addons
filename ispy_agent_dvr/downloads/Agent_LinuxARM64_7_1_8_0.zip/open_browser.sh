#!/bin/bash

# --- Default Configuration ---
DEFAULT_HOST="localhost"
DEFAULT_PORT=8090
SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
PORT_FILE="$SCRIPT_DIR/Media/XML/port.txt"

# --- Argument Parsing ---
INPUT_URL="$1" # Use argument 1 as URL

# --- URL Logic ---
if [ -z "$INPUT_URL" ]; then
    # No URL provided, construct from port file or defaults
    HOST="$DEFAULT_HOST"
    
    if [ -f "$PORT_FILE" ]; then
        PORT=$(cat "$PORT_FILE" | tr -d '\r\n')
        echo "Using port from file: $PORT"
    else
        PORT=$DEFAULT_PORT
        echo "Port file not found, using default: $PORT"
    fi
    
    URL="http://$HOST:$PORT"
    echo "Using default configuration: $URL"
else
    # URL provided, use it directly
    URL="$INPUT_URL"
    
    # Add http:// if no protocol specified
    if [[ ! "$URL" =~ ^https?:// && ! "$URL" =~ ^ftp:// ]]; then
        URL="http://$URL"
        echo "Added http:// protocol to URL"
    fi
    
    echo "Using specified URL: $URL"
fi

echo "Opening: $URL"

# --- WebRTC Flags ---
FLAGS="--webrtc-ip-handling-policy=default --allow-insecure-localhost --allow-running-insecure-content --autoplay-policy=no-user-gesture-required --disable-infobars --disable-extensions"

# --- Browser Search ---
echo "Searching for compatible browser..."

# List of browser commands to try in order
BROWSERS=(
    "google-chrome-stable"
    "google-chrome"
    "microsoft-edge-stable"
    "microsoft-edge"
    "brave-browser"
    "chromium-browser"
    "chromium"
    "vivaldi-stable"
    "vivaldi"
    "opera"
    "arc"
)

for browser in "${BROWSERS[@]}"; do
    if command -v "$browser" >/dev/null 2>&1; then
        echo "Found compatible browser: $browser"
        # Launch in the background
        nohup "$browser" $FLAGS --app="$URL" >/dev/null 2>&1 &
        echo "Browser launch initiated."
        
        # Display usage information
        echo
        echo "Usage: $0 [url]"
        echo "  url - Full URL to open (optional)"
        echo "        If not provided, uses localhost with port from port.txt (default: 8090)"
        echo "        Protocol (http://) will be added automatically if not specified"
        echo
        echo "Examples:"
        echo "  $0                              (uses localhost and port from file)"
        echo "  $0 localhost:3000               (opens http://localhost:3000)"
        echo "  $0 192.168.1.100:8080          (opens http://192.168.1.100:8080)"
        echo "  $0 https://example.com          (opens https://example.com)"
        echo "  $0 http://example.com:8080/app  (opens http://example.com:8080/app)"
        
        exit 0
    fi
done

# --- Fallback ---
echo "No compatible Chromium-based browser found in PATH, attempting to launch default browser."
echo "Warning: Required flags will not be applied."

if command -v xdg-open >/dev/null 2>&1; then
    nohup xdg-open "$URL" >/dev/null 2>&1 &
    echo "Browser launch initiated."
    
    # Display usage information
    echo
    echo "Usage: $0 [url]"
    echo "  url - Full URL to open (optional)"
    echo "        If not provided, uses localhost with port from port.txt (default: 8090)"
    echo "        Protocol (http://) will be added automatically if not specified"
    echo
    echo "Examples:"
    echo "  $0                              (uses localhost and port from file)"
    echo "  $0 localhost:3000               (opens http://localhost:3000)"
    echo "  $0 192.168.1.100:8080          (opens http://192.168.1.100:8080)"
    echo "  $0 https://example.com          (opens https://example.com)"
    echo "  $0 http://example.com:8080/app  (opens http://example.com:8080/app)"
    
    exit 0
else
    echo "Could not find a way to open the URL automatically."
    echo "Please open this URL in your browser: $URL"
    echo
    echo "Usage: $0 [url]"
    echo "  url - Full URL to open (optional)"
    echo "        If not provided, uses localhost with port from port.txt (default: 8090)"
    echo "        Protocol (http://) will be added automatically if not specified"
    
    exit 1
fi